package week2_pre_20242075;

public class problem01 {

	public static void main(String[] args) {
		System.out.print("Hello world!.");
	}

}
