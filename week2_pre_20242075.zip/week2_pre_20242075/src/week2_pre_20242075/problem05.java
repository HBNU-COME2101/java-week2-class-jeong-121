package week2_pre_20242075;
import java.util.Scanner;

public class problem05 {

	
	public static void main(String[] args) {
		System.out.print("나이를 입력하세요>>");
		Scanner scanner = new Scanner(System.in);
		int age = scanner.nextInt();
		if(age<=0) {
			System.out.print("나이는 양수로만 입력하세요.");
			System.exit(0);
		}
		int red = 10;
		int blue = 5;
		int yellow = 1;
		red = age/red;
		age -= red*10;
		blue = age/blue;
		age -= blue*5;
		yellow = age/yellow;
		if(red!=0) System.out.print("빨간 초 "+red+"개");
		if(blue!=0) System.out.print(", 파란 초 "+blue+"개");
		if(yellow!=0) System.out.print(", 노란 초 "+yellow+"개");
		System.out.print(". 총 "+(red+blue+yellow)+"개가 필요합니다.");
	}

}
