package week2_pre_20242075;
import java.util.Scanner;

public class problem04 {

	public static void main(String[] args) {
		System.out.print("여행지>>");
		Scanner scanner = new Scanner(System.in);
		String place = scanner.nextLine();

		System.out.print("인원수>>");
		int pnum = scanner.nextInt();
		

		System.out.print("숙박일>>");
		int snum = scanner.nextInt();
		

		System.out.print("1인당 항공료>>");
		int air = scanner.nextInt();

		System.out.print("1방 숙박비>>");
		int room = scanner.nextInt();
		scanner.close();

		System.out.print(pnum + "명의 " + place + snum+"박 "+snum+1+"일 여행에는 방 "+(snum/2+snum%2)+ "개 필요하며, 경비는 "+(air*pnum+room*(pnum/2+pnum%2)*snum)+"입니다.");
		
	}

}
