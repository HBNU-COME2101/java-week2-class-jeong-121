package week2_pre_20242075;
import java.util.Scanner;

public class chapter1_3 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		int birth = scanner.nextInt();
		int year = birth/10000;
		birth-=year*10000;
		int month = birth/100;
		birth-=month*100;
		int day = birth;
		System.out.printf("%d년 %d월 %d일\n", year, month, day);

	}

}
