package week2_pre_20242075;

public class problem02 {

	public static void main(String[] args) {
		System.out.print("20242075 정용성");

	}

}
